DROP DATABASE IF EXISTS mercadolibrenode;
CREATE DATABASE mercadolibrenode CHARACTER SET utf8mb4;
USE mercadolibrenode;