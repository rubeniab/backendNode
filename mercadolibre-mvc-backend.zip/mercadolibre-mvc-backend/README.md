# mercadolibre-mvc-backend
Práctica de Desarrollo de Proyecto Backend Seguro con NodeJS implementando los middlewares para una aplicación de compras. Implementación realizada para la Experiencia Educativa de Programación Segura de la Carrera de Ingeniería de Software en Universidad Veracruzana.
